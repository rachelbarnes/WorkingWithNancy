﻿namespace TexasHoldem
{
    public class Rules
    {
    }
}